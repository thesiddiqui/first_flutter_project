import 'package:flutter/material.dart';

main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomeApp(),
    );
  }
}

class HomeApp extends StatelessWidget {
  const HomeApp({Key? key}) : super(key: key);

  MyAlertDialog(context) {
    return showDialog(
        context: context,
        builder: (BuildContext) {
          return Expanded(
            child: AlertDialog(
              title: Text('Alert!!'),
              content: Text('Do you want to delete?'),
              actions: [
                TextButton(onPressed: (){}, child: Text('Yes')),
                TextButton(onPressed: (){
                  Navigator.pop(context);
                }, child: Text('No')),
              ],
            ),
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              padding: EdgeInsets.all(0),
              child: UserAccountsDrawerHeader(
                accountName: Text("Nayem Siddiqui"),
                accountEmail: Text("thesiddiqui@outlook.com"),
                currentAccountPicture: Image.network(
                    'https://www.shareicon.net/data/256x256/2015/06/21/57605_angry-birds_512x512.png'),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text("Home"),
              tileColor: Colors.blue,
              textColor: Colors.white,
              iconColor: Colors.white,
            ),
            ListTile(
              leading: Icon(Icons.search),
              title: Text("Search"),
            ),

            ListTile(
              leading: Icon(Icons.person),
              title: Text("Profile"),
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text("Settings"),
            ),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text("Logout"),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 1,
        items: [
          BottomNavigationBarItem(
              icon: Icon(Icons.newspaper), label: "News Paper"),
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile")
        ],
      ),
      body: Center(
          child: ElevatedButton(
        child: Text('Click Here'),
        onPressed: () {
          MyAlertDialog(context);
        },
      )),
    );
  }
}
